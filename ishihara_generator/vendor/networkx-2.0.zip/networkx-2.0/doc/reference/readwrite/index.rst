.. _readwrite:

**************************
Reading and writing graphs
**************************

.. toctree::
   :maxdepth: 2

   adjlist
   multiline_adjlist
   edgelist
   gexf
   gml
   gpickle
   graphml
   json_graph
   leda
   yaml
   sparsegraph6
   pajek
   nx_shp
